Interior CT 文献下载包

30 项文献：21 项 PDF，1 项正文全文（TXT/XML），8 项尚未取得全文。

范围：用户确认的30项，即最初清单编号1–15和深度学习清单编号1–15。
经典文献目录：classical/
深度学习目录：deep_learning/
打开“下载清单.html”可点击逐项查看本地文件、正式DOI、下载来源与未下载原因。
“方法分类.html”先分传统方法与深度学习方法（各15项），再分子类；CSV和RIS也包含两级分类与方法标签。
CSV清单可用Excel打开；references.ris可导入Zotero/EndNote。

版本说明：优先公开正式版；部分为作者接受稿或arXiv预印本，已标注。
TXT/XML仅代表官方公开的完整正文，没有原版PDF版式，图表参考原文页面。
A01为Natterer的1986年专著，不是期刊论文。
A10补全为2008年论文，DOI 10.3233/XST-2008-00207。
B08 arXiv上传于2025年，对应期刊论文发表于2022年。
B10、B14按正式卷期年列为2024、2026。

尚未取得全文：
A01 The Mathematics of Computerized Tomography
  https://doi.org/10.1007/978-3-663-01409-6
  未取得公开全文。出版社及开放获取元数据未提供可用的开放全文，需通过机构或个人订阅获取；已保留正式 DOI 入口。
A03 A two-step Hilbert transform method for 2D image reconstruction
  https://doi.org/10.1088/0031-9155/49/17/006
  发现出版社公开PDF及Frederic Noo在ResearchGate公开上传版本，但出版社返回Radware验证码页面、ResearchGate下载请求403；未将验证页保存为论文。
A04 Image reconstruction in peripheral and central regions-of-interest and data redundancy
  https://doi.org/10.1118/1.1844171
  未找到合法开放全文。OpenAlex无开放仓储；出版社PDF请求403；ResearchGate明确No full-text available。保留出版社入口，可通过机构订阅或向作者索取。
A05 Truncated Hilbert transform and image reconstruction from limited tomographic data
  https://doi.org/10.1088/0266-5611/22/3/019
  发现出版社公开PDF及Frederic Noo在ResearchGate公开上传版本，但出版社返回验证HTML、ResearchGate下载请求403；HAL记录仅元数据无全文。
A08 Tiny a priori knowledge solves the interior problem in computed tomography
  https://doi.org/10.1088/0031-9155/53/9/001
  筑波大学仓储公开提供作者接受稿，但下载服务器持续503，旧重定向为过期签名链接；未取得PDF。保留公开仓储入口以便恢复后下载。
A11 Singular value decomposition for the truncated Hilbert transform
  https://doi.org/10.1088/0266-5611/26/11/115011
  未找到合法可直接下载的公开全文。出版社PDF未返回文献；UCF机构库只有书目信息，明确未收录全文。
A12 Singular value decomposition for the truncated Hilbert transform: Part II
  https://doi.org/10.1088/0266-5611/27/7/075006
  未找到合法可直接下载的公开全文。出版社PDF未返回文献；UCF机构库只有书目信息，明确未收录全文。
B15 A Two-Module Parallel Dual-Domain Network for interior tomography reconstruction
  https://doi.org/10.1177/08953996261433954
  未取得公开全文。出版社及开放获取元数据未提供可用的开放全文，需通过机构或个人订阅获取；已保留正式 DOI 入口。
